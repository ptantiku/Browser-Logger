<html>
<head>
	<title>UCI Web-Search Logger: Reminder</title>
</head>
<body>
<h1>UCI Web-Search Logger: Reminder</h1>
<div>
Thank you very much for your help with this research study. <br>
Please, review and submit your recent searches.
</div>
<br>
<button id="submit" onclick="location.href='review.php'">Review and Submit</button>
</body>
</html>
