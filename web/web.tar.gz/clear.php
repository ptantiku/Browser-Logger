<html>
<body>
	This page is for automatically clearing logged data in your machine.
</body>
</html>
